#pragma once

#include <string>
#include <vector>
#include <set>

//======================= TOKEN TYPE =======================

enum class TokenType {

	BRACKET,
	CONST,
	VARIABLE,
	OPERATOR,
	FUNCTION,
	UNKNOWN

};



//========================= TOKEN =========================

class Token {

private:

	TokenType tokenType;
	std::string value;
	

public:
	Token(TokenType _tokenType, const std::string& _value) : tokenType(_tokenType), value(_value) { }

	Token(const Token& token);
	Token& operator=(const Token& token);

	bool operator==(const Token& token) const;

	TokenType GetTokenType() const { return tokenType; }
	std::string GetValue() const { return value; }

};


//========================= TOKENIZER =========================

class Tokenizer {

private:

	std::string infix;
	
	std::vector<std::string> operators;
	std::vector<std::string> functionNames;
	std::vector<std::string> variableNames;


public:

	Tokenizer(
		const std::string& _infix, 
		const std::vector<std::string>& _operators,
		const std::vector<std::string>& _functionNames,
		const std::vector<std::string>& _variableNames
	): 
		infix(_infix), 
		operators(_operators),
		functionNames(_functionNames),
		variableNames(_variableNames)
	{};

	Tokenizer(const Tokenizer& tokenizer) = delete;
	Tokenizer& operator=(const Tokenizer& tokenizer) = delete;

	std::vector<Token> ToTokens() const;

private:

	void FillUniqueOperatorsChars(std::set<char>& s) const;

	size_t FindEndIndexOfNumber(const std::string& str, size_t startIndex) const;
	size_t FindEndIndexOfLatin(const std::string& str, size_t startIndex) const;
	size_t FindEndIndexOfOperator(const std::string& str, size_t startIndex, const std::set<char>& allowedSymbols) const;


};


//========================= VALIDATOR =========================

class Validator {

private:

	std::vector<Token> tokens;

public:

	Validator(const std::vector<Token>& _tokens) : tokens(_tokens) {}
	bool IsValid();

	Validator(const Validator& validator) = delete;
	Validator& operator=(const Validator& validator) = delete;

};
