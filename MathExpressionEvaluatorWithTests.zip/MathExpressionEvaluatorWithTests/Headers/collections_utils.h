#pragma once

#include <string>
#include <set>
#include <vector>

class Collections {

public:
	static void ReplaceAll(std::string& str, const std::string toReplace, const std::string replaceWith);
	
	template<class T>
	static bool VectorContains(const std::vector<T>& v, const T& element);

	template<class T>
	static bool SetContains(const std::set<T>& s, const T& element);


private:

	Collections() = delete;
	Collections(const Collections& collections) = delete;


};

template<class T>
inline bool Collections::VectorContains(const std::vector<T>& v, const T& element) 
{
	return !v.empty() && std::find(v.begin(), v.end(), element) != v.end();
}

template<class T>
inline bool Collections::SetContains(const std::set<T>& s, const T& element) 
{
	return !s.empty() && s.find(element) != s.end();
}


