#include <gtest/gtest.h>
#include "../Headers/expressions.h"


std::string ToString(const TokenType& type) {
	switch (type)
	{
		case TokenType::BRACKET:
		return "BRACKET";
		case TokenType::CONST:
		return "CONST";
		case TokenType::VARIABLE:
		return "VARIABLE";
		case TokenType::OPERATOR:
		return "OPERATOR";
		case TokenType::FUNCTION:
		return "FUNCTION";
		case TokenType::UNKNOWN:
		return "UNKNOWN";
	}
	throw "Unknown TokenType";
}

TEST(Tokenizer, Tokenize) {
	std::string infix = "a+b*cos((20/tmp))-sqrt(19.563^cc)";

	std::vector<std::string> operators = {"+", "-", "*", "/", "^"};
	std::vector<std::string> functionNames = {"cos", "sqrt"};
	std::vector<std::string> variableNames = {"a", "b", "cc", "tmp"};

	Tokenizer tokenizer(infix, operators, functionNames, variableNames);

	std::vector<Token> tokens = tokenizer.ToTokens();

	std::cout << std::endl;
	for (const auto& token : tokens) {
		std::cout << ToString(token.GetTokenType()) << ": " << token.GetValue() << std::endl;
	}
	EXPECT_TRUE(1 == 1);
}