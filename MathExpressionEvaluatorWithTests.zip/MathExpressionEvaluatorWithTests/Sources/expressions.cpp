#include "../Headers/expressions.h"

#include <set>
#include "../Headers/collections_utils.h"


//========================= TOKEN =========================


//========================= TOKEN =========================

Token::Token(const Token& token)
{
	this->tokenType = token.tokenType;
	this->value = token.value;
}

Token& Token::operator=(const Token& token)
{
	this->tokenType = token.tokenType;
	this->value = token.value;

	return *this;
}

bool Token::operator==(const Token& token) const
{
	return this->tokenType == token.tokenType && this->value == token.value;
}

//========================= TOKENIZER =========================

std::vector<Token> Tokenizer::ToTokens() const
{
	std::vector<Token> tokens;
	
	std::string infix = this->infix;

	Collections::ReplaceAll(infix, " ", "");

	int pos = 0;

	std::set<char> uniqueOperatorChars;
	FillUniqueOperatorsChars(uniqueOperatorChars);

	while (pos < infix.length())
	{
		if (infix[pos] == '(' || infix[pos] == ')') {
			
			std::string symbol(1, infix[pos]);

			Token token(TokenType::BRACKET, symbol);
			tokens.push_back(token);

			pos++;
			continue;
		}

		if (infix[pos] >= '0' && infix[pos] <= '9') {

			size_t endPos = FindEndIndexOfNumber(infix, pos);
			
			Token token(TokenType::CONST, infix.substr(pos, (endPos - pos + 1)));
			tokens.push_back(token);

			pos += (endPos - pos + 1);
			continue;
		}

		if (infix[pos] >= 'a' && infix[pos] <= 'z') {
			size_t endPos = FindEndIndexOfLatin(infix, pos);

			std::string sub = infix.substr(pos, (endPos - pos + 1));

			if (Collections::VectorContains(functionNames, sub)) {

				Token token(TokenType::FUNCTION, sub);
				tokens.push_back(token);

				pos += (endPos - pos + 1);
				continue;
			}

			if (Collections::VectorContains(variableNames, sub)) {

				Token token(TokenType::VARIABLE, sub);
				tokens.push_back(token);

				pos += (endPos - pos + 1);
				continue;
			}

			Token token(TokenType::UNKNOWN, sub);
			tokens.push_back(token);

			pos += (endPos - pos + 1);
			continue;

		}

		if (Collections::SetContains(uniqueOperatorChars, infix[pos])) {

			size_t endPos = FindEndIndexOfOperator(infix, pos, uniqueOperatorChars);
			std::string sub = infix.substr(pos, (endPos - pos + 1));

			if (Collections::VectorContains(operators, sub)) {

				Token token(TokenType::OPERATOR, sub);
				tokens.push_back(token);

				pos += (endPos - pos + 1);
				continue;
			}

			Token token(TokenType::UNKNOWN, sub);
			tokens.push_back(token);

			pos += (endPos - pos + 1);
			continue;

		}

		std::string symbol(1, infix[pos]);

		Token token(TokenType::UNKNOWN, symbol);
		tokens.push_back(token);

		pos++;

	}

	return tokens;

}


void Tokenizer::FillUniqueOperatorsChars(std::set<char>& s) const
{
	for (const auto& op : operators)
	{
		for (const char& c : op) {
			s.insert(c);
		}
	}
}

size_t Tokenizer::FindEndIndexOfNumber(const std::string& str, size_t startIndex) const
{
	size_t endIndex = startIndex + 1;

	bool hasDot = false;
	
	while (endIndex < str.length())
	{
		if (str[endIndex] >= '0' && str[endIndex] <= '9') {
			endIndex++;
			continue;
		}

		if (str[endIndex] == '.') {
			if (!hasDot) {
				hasDot = true;
				endIndex++;
				continue;
			}
		}

		break;
	}

	return endIndex - 1;

}

size_t Tokenizer::FindEndIndexOfLatin(const std::string& str, size_t startIndex) const
{
	size_t endIndex = startIndex + 1;

	while (endIndex < str.length())
	{
		if (str[endIndex] >= 'a' && str[endIndex] <= 'z') {
			endIndex++;
			continue;
		}

		break;
	}

	return endIndex - 1;
}

size_t Tokenizer::FindEndIndexOfOperator(const std::string& str, size_t startIndex, const std::set<char>& allowedSymbols) const
{
	size_t endIndex = startIndex + 1;

	while (endIndex < str.length())
	{
		if (Collections::SetContains(allowedSymbols, str[endIndex])) {
			endIndex++;
			continue;
		}

		break;
	}

	return endIndex - 1;
}


//========================= VALIDATOR =========================

bool Validator::IsValid()
{
	int tokenIndex = 0;

	while (tokenIndex < tokens.size())
	{
		Token& token = tokens[tokenIndex];
		if (token.GetTokenType() == TokenType::FUNCTION) {

		}
	}

}
